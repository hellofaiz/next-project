
import Head from 'next/head'

export default function Register() {
  return (
    <div className="container">
      <Head>
        <title>Register</title>
        <link rel="icon" href="/vercel.svg" />

      </Head>
      <main>
        <h1 className=" text-3xl font-bold underline">This is Register</h1>
       
      </main >
    </div>

  )
}
