import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
require('dotenv').config();

// const crypto = require('crypto');
// const secret = crypto.randomBytes(32).toString('hex');
const secret = 'DYOTIS'
export default NextAuth({
  // Configure one or more authentication providers
  // site: process.env.NEXTAUTH_URL,
  providers: [
    GoogleProvider({
      clientId: process.env.NEXT_PUBLIC_CLIENT_ID,
      clientSecret: process.env.NEXT_PUBLIC_SECRET,
      // authorization: {
      //   params: {
      //     prompt: "consent",
      //     access_type: "offline",
      //     response_type: "code"
      //   }
      // }
    })
  ],
  //   callbacks: {
  //     async redirect(params) {
  //       const { url } = params;

  //       // url is just a path, e.g.: /videos/pets
  //       if (!url.startsWith('http')) return url;

  //       // If we have a callback use only its relative path
  //       const callbackUrl = new URL(url).searchParams.get('callbackUrl');
  //       if (!callbackUrl) return url;

  //       return "https://picfix.ai";
  //     },
  //   },
  // callbacks: {
  //   async signIn(user, account, profile) {
  //     // Custom logic after successful sign-in
  //     return true;
  //   },
  //   async redirect(url, baseUrl) {
  //     // Custom logic to redirect to the desired path after authentication
  //     return url.startsWith(baseUrl) ? url : baseUrl;
  //   },
  // },
  secret
});
