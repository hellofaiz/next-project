"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/google"
const google_namespaceObject = require("next-auth/providers/google");
var google_default = /*#__PURE__*/__webpack_require__.n(google_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js


(__webpack_require__(142).config)();
// const crypto = require('crypto');
// const secret = crypto.randomBytes(32).toString('hex');
const secret = "DYOTIS";
/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    // Configure one or more authentication providers
    // site: process.env.NEXTAUTH_URL,
    providers: [
        google_default()({
            clientId: "181404974898-v1utqmca6c4qfordall8s2jcdnpm9mft.apps.googleusercontent.com",
            clientSecret: "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"
        })
    ],
    //   callbacks: {
    //     async redirect(params) {
    //       const { url } = params;
    //       // url is just a path, e.g.: /videos/pets
    //       if (!url.startsWith('http')) return url;
    //       // If we have a callback use only its relative path
    //       const callbackUrl = new URL(url).searchParams.get('callbackUrl');
    //       if (!callbackUrl) return url;
    //       return "https://picfix.ai";
    //     },
    //   },
    // callbacks: {
    //   async signIn(user, account, profile) {
    //     // Custom logic after successful sign-in
    //     return true;
    //   },
    //   async redirect(url, baseUrl) {
    //     // Custom logic to redirect to the desired path after authentication
    //     return url.startsWith(baseUrl) ? url : baseUrl;
    //   },
    // },
    secret
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(507));
module.exports = __webpack_exports__;

})();